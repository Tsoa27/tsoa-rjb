Solitaire Chinois-----------------
Url     : http://codes-sources.commentcamarche.net/source/102110-solitaire-chinoisAuteur  : MintsDate    : 16/08/2017
Licence :
=========

Ce document intitul� � Solitaire Chinois � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un solitaire chinois réalisé avec pygame 1.9
<br />
<br />Pour les sprites j
'ai fait avec les moyens du bord mais y'a 7 modèles différents.
<br />Je n'ai
 pas activé les sons pour le moment pour ne pas trop parasiter la musique 
<br
 />en attendant d'en trouver de meilleurs.
<br />
<br />Pour gagner la partie 
il ne doit rester qu'un seul pion sur le plateau.
<br />Lorsqu'un pion saute pa
r dessus un autre verticalement,horizontalement ou diagonalement
<br />ce derni
er disparait.
<br />                
<br />N'hésitez pas à le passer en plei
n écran via le menu options.
<br />
<br />En attente de retours, bonne contin
uation.
